![Jorels](https://www.jorels.com/web/image/res.company/1/logo)
### Jorels SAS - Copyright (2019-2023)

# Ciiu's for Colombia

## Module name
l10n_co_ciius

## Support

[info@jorels.com](mailto:info@jorels.com)

[Telegram: @Jorels_SAS](https://t.me/Jorels_SAS)

[https://www.jorels.com](https://www.jorels.com)

## Authors and acknowledgment
Jorels SAS

## License
Under LGPL (Lesser General Public License)

## Project status
Tested in production on Odoo 12, 13, 14, 15 y 16.

## Description
Ciiu's for Colombia
