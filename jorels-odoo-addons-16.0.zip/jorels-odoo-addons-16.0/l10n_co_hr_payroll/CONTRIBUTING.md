Jorels SAS
----------

Desarrollo
==========
Jorge Sanabria (2021-2022). Desarrollo del código fuente del modulo

Aportes de conocimiento
=======================
David Alejandro De La Rosa Maldonado (2021-2022). Asesoría el desarrollo con sus grandes conocimientos en el tema de
nómina de Odoo

July Marcela Caballero Martinez (2022). Asesoría en el tema de nómina e interfaz de usuario